package com.shoppingCart.service;

import com.shoppingCart.model.Cart;

public interface CartService {

    Cart getCartById(int cartId);

    void update(Cart cart);
}
