package com.shoppingCart.controller.adminHome;

import com.shoppingCart.model.Customer;
import com.shoppingCart.model.Product;
import com.shoppingCart.service.CustomerService;
import com.shoppingCart.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/adminHome")
public class AdminHome {

    @Autowired
    private ProductService productService;

    @Autowired
    private CustomerService customerService;

    @RequestMapping
    public String adminHomePage(){
        return "adminHome";
    }

    @RequestMapping("/manageProducts")
    public String manageProducts(Model model){
        List<Product> products = productService.getProductList();
        model.addAttribute("products", products);

        return "manageProducts";
    }

    @RequestMapping("/manageUsers")
    public String customerManagerment(Model model){

        List<Customer> customerList = customerService.getAllCustomers();
        model.addAttribute("customerList", customerList);

        return "manageUsers";
    }


} // The End of Class;



